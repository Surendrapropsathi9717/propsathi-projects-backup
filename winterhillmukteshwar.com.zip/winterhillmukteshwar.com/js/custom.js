
$(document).ready(function() {
	"use strict";
	$(document).ready(function () {
		$(".menuBtn, .menuContainer").click(function() {
			$('.menuBtn, .menuContainer').toggleClass('closeMenuBtn');
			$('.menuContainer').stop().fadeToggle(500).toggleClass('active');
			$('body').toggleClass('overflow-hidden');
		});
		});
  $('[data-toggle="tooltip"]').tooltip();
	$(window).bind('scroll', function () {
		if ($(window).scrollTop() > 100) {
			$('.button-top').animate({
				opacity:1
			},0);
		}
		else {
			$('.button-top').animate({
				opacity:0
			},0);
		}
	});
	$(".button-top").click(function(){
	   $("html,body").animate({scrollTop:'0px'},500);
	});
});