<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Thank You </title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <style>
    body {
      margin: 0;
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      background: linear-gradient(to right, #1c1c1c, #0f0f0f);
      color: #ffffff;
      display: flex;
      justify-content: center;
      align-items: center;
      height: 100vh;
      overflow: hidden;
    }

    .thank-you-box {
      text-align: center;
      padding: 50px 30px;
      background: rgba(255, 255, 255, 0.05);
      border: 1px solid rgba(255, 255, 255, 0.1);
      border-radius: 20px;
      box-shadow: 0 10px 25px rgba(0,0,0,0.5);
      max-width: 600px;
      backdrop-filter: blur(15px);
    }

    .thank-you-box h1 {
      font-size: 48px;
      margin-bottom: 10px;
      color: #e6b70a;
    }

    .thank-you-box p {
      font-size: 18px;
      color: #ccc;
      margin-bottom: 30px;
    }

    .thank-you-box .home-btn {
      display: inline-block;
      padding: 12px 30px;
      font-size: 16px;
      border-radius: 50px;
      background-color: #e6b70a;
      color: #000;
      text-decoration: none;
      font-weight: bold;
      transition: background-color 0.3s ease;
    }

    .thank-you-box .home-btn:hover {
      background-color: #cfa209;
    }

    .logo {
      margin-bottom: 30px;
    }
 
    .logo img {
      width: 120px;
    }

    @media (max-width: 600px) {
      .thank-you-box h1 {
        font-size: 36px;
      }
      .thank-you-box p {
        font-size: 16px;
      }
    }
  </style>
</head>
<body>

  <div class="thank-you-box">
    <div class="logo">
      <img src="https://winterhill.in/winterhill/images/logo-white.png" alt=""> <!-- Replace with actual logo path -->
    </div>
    <h1>Thank You!</h1>
    <p>Your enquiry has been successfully submitted.<br>Our team will connect with you shortly.</p>
    <a href="/" class="home-btn">Return to Home</a>
  </div>
<script>
  setTimeout(function() {
    window.location.href = '/'; // Change to 'index.php' if needed
  }, 5000); // 5000 ms = 5 seconds
</script>

</body>
</html>
