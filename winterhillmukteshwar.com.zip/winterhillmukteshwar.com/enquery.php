<?php 
session_start();
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'vendor/autoload.php'; 

if(isset($_POST['submit'])){ 
   
  //  if($_POST['captchaAnswer'] == $_POST['captchaInput']) { 
    $name = $_POST['clname'];
    $email = $_POST['clemail'];
    $contact = $_POST['clphone'];
    $city = $_POST['city'];
   
            $subject = "New Enquiry has been Submitted Successfully.";
           // $headers = "MIME-Version: 1.0" . "\r\n";
            $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n"; 
			$headers .= 'From:  WINTER HILL LUXURY PLOT, MUKTESHWAR <info@winterhill.in>' . "\r\n";			
            $body = "
            <html> 
             <body>";
           
			 $body .= "<div class='row'>";
           $body .= "<div class='col-md-12' id='tatalCaptcha' style='float:left'>";
			$body .= '<table width="400" border="0" align="center" cellpadding="5" cellspacing="1" class="table" id="tatalCaptcha">';
			$body .= '<tr style="background: #1b93e1;color: #fff;">
							<td colspan="2" align="center" valign="top" style="color: white;font-size: 18px;text-align: center;">
						New Enquiry Details </td>
                     </tr>';
			 
			$body .= '<tr>' ;
			$body .= '<td style="background: #e74c3c;Color:#fff;text-align:center;width:50%">Name</td>';
			$body .= '<td style="text-align:center;width:50%;background:#e6b70a;color:#fff" id="trueWork">'.$name.'</td>';
			$body .= '</tr>';
			
			$body .= '<tr>' ;
			$body .= '<td style="background: #e74c3c;Color:#fff;text-align:center;width:50%">Email  </td>';
			$body .= '<td style="text-align:center;width:50%;background:#e6b70a;color:#fff" id="trueWork">'.$email.'</td>';
			$body .= '</tr>';
			
			$body .= '<tr>' ;
			$body .= '<td style="background: #e74c3c;Color:#fff;text-align:center;width:50%">Phone Number</td>';
			$body .= '<td style="text-align:center;width:50%;background:#e6b70a;color:#fff" id="trueWork">'.$contact.'</td>';
			$body .= '</tr>';
			
			$body .= '<tr>' ;
			$body .= '<td style="background: #e74c3c;Color:#fff;text-align:center;width:50%">City</td>';
			$body .= '<td style="text-align:center;width:50%;background:#e6b70a;color:#fff" id="trueWork">'.$city.'</td>';
			$body .= '</tr>';
			
			
			
		 
			 
			 

$body .= "<div class='col-md-12' style='margin-top:30px;width:100%'>
							<h4>Thanks</h4>
                            <b>WINTER HILL, MUKTESHWAR</b>
							<b>https://winterhillmukteshwar.com/</b>
						</div>"; 
			$body .= '</div>';
			$body .= "</table>"; //closes the table
			 
			 
			 
            $message .= $body . "
            </body>
            </html>";
            $message = wordwrap($message, 70); 
            
            
            
            // PHPMailer Setup
            $mail = new PHPMailer(true);
            $subject = "Winter hill luxury plots Enqiry";
            try {
                // Server settings
                $mail->isSMTP();
                $mail->Host = 'mail.winterhillmukteshwar.com'; 
                $mail->SMTPAuth = true;
                $mail->Username = 'info@winterhillmukteshwar.com';  
                $mail->Password = '4jr0BK1yo4BIygpv';  
                $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
                $mail->Port = 587;

            
                // Recipients
                
               $to= 'winterhillbysagar@gmail.com';  
              // $to= 'surendra.imsec@gmail.com';   
                // foreach ($to as $recipient) {
                //     $mail->addAddress($recipient); // Add each recipient to the email
                // } 
                
                 $mail->addAddress($to);
                $mail->setFrom('info@winterhillmukteshwar.com', 'WINTER HILL, MUKTESHWAR PLOT ENQUIRY');
                  
                $mail->isHTML(true);
                $mail->Subject = $subject;
                $mail->Body    = $message;
            
             if($mail->send()) {
               	echo "<script> 
            window.location.href = 'thank-you.php';
          </script>";
             exit;
            } else {
                	echo "<script>alert('Query Failed')</script>";
            }
            }catch (Exception $e) { 
                	echo "<script>alert('Query Failed')</script>";
} 
           
} 

?>
