<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Privacy Policy | Eden Mukteshwar</title>
  <meta name="description" content="Read the Privacy Policy of Eden Mukteshwar to understand how we collect, use, and protect your personal information when you visit our website.">

  <style>
    /* ---------- General ---------- */
    body {
      margin: 0;
      font-family: Inter, system-ui, -apple-system, 'Segoe UI', Roboto, 'Helvetica Neue', Arial;
      background: #f7f8fb;
      color: #0f172a;
      line-height: 1.6;
    }

    /* ---------- Banner ---------- */
    .policy-header {
      background: linear-gradient(135deg, #2b4d3f, #416b59);
      color: #fff;
      text-align: center;
      padding: 80px 20px;
    }

    .policy-header h1 {
      font-size: 38px;
      margin-bottom: 10px;
    }

    .policy-header p {
      font-size: 16px;
      opacity: 0.9;
      margin: 0;
    }

    /* ---------- Main Privacy Layout ---------- */
    .privacy-wrap {
      padding: 70px 16px;
      display: flex;
      justify-content: center;
    }

    .privacy-container {
      max-width: 1100px;
      width: 100%;
      background: #ffffff;
      border-radius: 12px;
      box-shadow: 0 6px 18px rgba(16,24,40,0.08);
      padding: 32px;
      display: grid;
      grid-template-columns: 1fr 300px;
      gap: 30px;
    }

    .privacy-article h2 {
      color: #0b5fff;
      font-size: 20px;
      margin-top: 28px;
    }

    .privacy-article p {
      line-height: 1.7;
      color: #24303f;
      margin: 10px 0;
    }

    .privacy-article ul {
      margin: 8px 0 16px 20px;
    }

    .privacy-article li {
      margin: 6px 0;
      color: #24303f;
    }

    /* ---------- Sidebar ---------- */
    .privacy-aside {
      position: sticky;
      top: 32px;
      height: max-content;
    }

    .privacy-toc {
      background: #fff;
      border-radius: 10px;
      padding: 14px;
      border: 1px solid rgba(12,22,45,0.05);
      box-shadow: 0 4px 8px rgba(0,0,0,0.03);
    }

    .privacy-toc h3 {
      margin: 0 0 10px;
      font-size: 15px;
      color: #1e3a2f;
    }

    .privacy-toc a {
      display: block;
      padding: 8px 6px;
      border-radius: 8px;
      color: #0b5fff;
      text-decoration: none;
      font-size: 14px;
    }

    .privacy-toc a:hover {
      background: rgba(11,95,255,0.06);
    }

    .privacy-contact {
      margin-top: 18px;
      padding: 12px;
      border-radius: 8px;
      background: linear-gradient(180deg, #fff, #fbfdff);
      border: 1px dashed rgba(11,95,255,0.1);
    }

    .privacy-contact a {
      color: #0b5fff;
      text-decoration: none;
    }

    /* ---------- Footer ---------- */
    .privacy-footer {
      margin-top: 30px;
      text-align: center;
      color: #6b7280;
      font-size: 13px;
      border-top: 1px solid rgba(0,0,0,0.05);
      padding-top: 10px;
    }

    /* ---------- Responsive ---------- */
    @media (max-width: 900px) {
      .privacy-container {
        grid-template-columns: 1fr;
      }
      .privacy-aside {
        position: static;
      }
      .policy-header h1 {
        font-size: 30px;
      }
    }
  </style>
</head>
<body>

  <!-- Banner Section -->
  <header class="policy-header">
    <h1>Privacy Policy</h1>
    <p>Your privacy is important to us at Eden Mukteshwar</p>
  </header>

  <!-- Main Content -->
  <div class="privacy-wrap">
    <div class="privacy-container">

      <main class="privacy-article">
        <p>
          Welcome to <strong>Eden Mukteshwar</strong>. We respect your privacy and are committed to protecting your personal information. 
          This Privacy Policy explains how we collect, use, and safeguard your data when you visit our website 
          <a href="https://edenmukteshwar.com" target="_blank">https://edenmukteshwar.com</a>.
        </p>

        <h2 id="info">1. Information We Collect</h2>
        <p>We may collect the following types of information:</p>
        <ul>
          <li><strong>Personal Information:</strong> Name, phone number, and city provided through enquiry or contact forms.</li>
          <li><strong>Technical Data:</strong> IP address, browser type, operating system, device info, and pages visited.</li>
          <li><strong>Cookies:</strong> Used to enhance experience and analyze usage patterns.</li>
        </ul>

        <h2 id="use">2. How We Use Your Information</h2>
        <ul>
          <li>To respond to enquiries and provide requested information.</li>
          <li>To improve our website and personalize your experience.</li>
          <li>To send promotional updates (only with consent).</li>
          <li>To analyze usage for better marketing strategies.</li>
        </ul>

        <h2 id="legal-basis">3. Legal Basis for Processing</h2>
        <ul>
          <li>Your consent for communication.</li>
          <li>To fulfill contracts or service requests.</li>
          <li>Legal compliance requirements.</li>
          <li>Legitimate interest in service improvement.</li>
        </ul>

        <h2 id="security">4. Data Security</h2>
        <p>We use technical and organizational safeguards to protect your data. However, no online system is 100% secure.</p>

        <h2 id="cookies">5. Cookies Policy</h2>
        <p>Cookies enhance your experience and track analytics. You can disable cookies via browser settings, though it may affect functionality.</p>

        <h2 id="third-party">6. Third-Party Sharing</h2>
        <p>We do not sell your personal data. We may share it with trusted service providers under strict confidentiality, or disclose it when required by law.</p>

        <h2 id="links">7. External Links</h2>
        <p>Our site may link to third-party websites. We are not responsible for their content or privacy policies.</p>

        <h2 id="rights">8. Your Rights</h2>
        <ul>
          <li>Access or request a copy of your data.</li>
          <li>Correct or update inaccurate details.</li>
          <li>Withdraw consent for marketing.</li>
          <li>Request deletion of your data (where applicable).</li>
        </ul>

        <h2 id="retention">9. Retention of Data</h2>
        <p>We retain data as long as necessary for business, legal, or contractual purposes. It’s securely deleted afterward.</p>

        <h2 id="children">10. Children’s Privacy</h2>
        <p>Our website is not intended for users under 18. If a child provides personal info, contact us for prompt deletion.</p>

        <h2 id="updates">11. Policy Updates</h2>
        <p>We may modify this policy anytime. The latest version with the effective date will always be on this page.</p>

        <h2 id="contact">12. Contact Us</h2>
        <p>
          <strong>Eden Mukteshwar</strong><br>
          Mukteshwar, Nainital, Uttarakhand, India<br>
          Phone: +91-9990711766<br>
          Website: <a href="https://edenmukteshwar.com" target="_blank">www.edenmukteshwar.com</a><br><br>
          <em>Effective Date:</em> <span id="effectiveDate"></span>
        </p>

        <footer class="privacy-footer">
          © <span id="year"></span> Eden Mukteshwar. All Rights Reserved.
        </footer>
      </main>

      <!-- Sidebar -->
      <aside class="privacy-aside">
        <div class="privacy-toc">
          <h3>Quick Navigation</h3>
          <a href="#info">Information We Collect</a>
          <a href="#use">How We Use Your Information</a>
          <a href="#legal-basis">Legal Basis for Processing</a>
          <a href="#security">Data Security</a>
          <a href="#cookies">Cookies Policy</a>
          <a href="#third-party">Third-Party Sharing</a>
          <a href="#links">External Links</a>
          <a href="#rights">Your Rights</a>
          <a href="#retention">Retention of Data</a>
          <a href="#children">Children’s Privacy</a>
          <a href="#updates">Policy Updates</a>
          <a href="#contact">Contact Us</a>
        </div>

        <div class="privacy-contact">
          <strong>Need Help?</strong>
          <p style="margin:6px 0 0;color:#6b7280;font-size:14px">
            Contact us at <a href="tel:9990711766">9990711766</a>
          </p>
        </div>
      </aside>

    </div>
  </div>

  <script>
    document.getElementById("year").textContent = new Date().getFullYear();
    document.getElementById("effectiveDate").textContent = new Date().toLocaleDateString();
  </script>

</body>
</html>
