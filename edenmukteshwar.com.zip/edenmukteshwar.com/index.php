<?php
define('BASE_URL', 'https://pcrm.in/landing-website-setting');
?>
<!DOCTYPE html><html lang="en"><head>
    <!-- Character Set & Viewport -->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- SEO Meta Tags -->
    <title>Eden Luxury Villas Mukteshwar | Ultra Luxury 4 BHK in Ramgarh, Nainital</title>
    <meta name="description" content="Discover Eden Luxury Villas in Mukteshwar, Nainital. Ultra-luxury 3 BHK hilltop homes with Himalaya views. Starting ₹4.99 Cr*. Book your site visit today!">
    <meta name="keywords" content="Eden Mukteshwar, Eden Mukteswar, Eden Mukteshwer, Luxury Villas Mukteshwar, 4 BHK + Servant Room Villas, Ultra Luxury Homes, Hilltop Villas, Himalayan Views, Mukteshwar Properties, Mukteshwar Land, Mukteshwar Plots, Mukteshwar Villas, Mukteshwar Real Estate, Mukteshwar Investment, Ramgarh Nainital, Mukteshwar Houses, Mukteshwar Homes"><meta name="robots" content="index, follow">

    <!-- Google Site Verification -->
    <meta name="google-site-verification" content="cMLMiDRtwj0yv4E3oJ0aV4wGSPLD1hkm_yKGCZjXUA8" />

    <!-- Favicon --> 
    <!-- Standard favicon -->
<link rel="icon" href="<?php echo BASE_URL; ?>/images/eden_favicon.ico" sizes="any">

<!-- PNG fallback (better for SEO + modern browsers) -->
<link rel="icon" type="image/png" href="<?php echo BASE_URL; ?>/images/favicon-32x32.png" sizes="32x32">
<link rel="icon" type="image/png" href="<?php echo BASE_URL; ?>/images/favicon-16x16.png" sizes="16x16">

    <!-- Social Sharing (Optional but boosts SEO) -->
    <meta property="og:title" content="Eden Luxury Villas Mukteshwar | Ultra Luxury 4 BHK in Ramgarh, Nainital">
    <meta property="og:description" content="Discover Eden Luxury Villas in Mukteshwar, Nainital. Ultra-luxury 3 BHK hilltop homes with Himalaya views. Starting ₹4.99 Cr*.">
    <meta property="og:image" content="images/eden_social_preview.jpg">
    <meta property="og:url" content="https://edenmukteshwar.com/">
    <meta name="twitter:card" content="summary_large_image">

    <!-- CSS & Fonts -->
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/font-family.css">
    <link rel="stylesheet" href="css/all.min.css" crossorigin="anonymous" referrerpolicy="no-referrer">
 
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/btn.css">
    <link rel="stylesheet" href="css/play-btn.css">
    <link rel="stylesheet" href="css/font-family.css">
    <link rel="stylesheet" href="css/keyframes.css">
    <link rel="stylesheet" href="css/responsive.css">
    <link rel="stylesheet" href="css/all.min.css" crossorigin="anonymous" referrerpolicy="no-referrer">
        <style>
            .image-hover-effect {
    position: relative;
    display: inline-block;
    width: fit-content;
}

.location_img {
    display: block;
    width: 100%;
    height: auto;
    border-radius: 10px;
}

.view-map-btn {
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    background-color: #b28e3b;
    color: white;
    border: none;
    padding: 10px 20px;
    font-weight: bold;
    border-radius: 5px;
    cursor: pointer;
    transition: background-color 0.3s ease;
    text-decoration: none;
}

.view-map-btn:hover 
 {
    background-color: transparent;
    color: #b28e3b;
}

.form-control, .modal .modal-body input{ 
    height: 40px;
}

@media (min-width: 1200px) and (max-width: 1600px) {
    .bg-content .reg_form form input 
 {
        height: 40px;
    }
}

@media (max-width: 767px) {
    .bg-content .bg_details .card li 
 {
        font-size: 15px;
        text-align: justify;
    }
}

@media (min-width: 1200px) and (max-width: 1600px) {
    .pt2 {
        padding: 30px 0px !important;
    }
}

.waves { 
    background: #fff;
}

.navbar-toggler{
    color: #fff;
    background: #b28e3b;
}



@media (max-width: 700px) {
    .phone i {
        background: #b28e3b;
        color: #ffffff;
        border: 1px solid #fff;
    }
    
    .navbar-collapse {
    background: #404040;
    flex-basis: 100%;
    padding: 15px;
    
}
}



@media (max-width: 768px) {
    .navbar-brand img {
        width: 118px !important;
        height: 40px !important;
    }
}

        </style>
 

 
        <!-- Meta Pixel Code -->
<script>
!function(f,b,e,v,n,t,s)
{if(f.fbq)return;n=f.fbq=function(){n.callMethod?
n.callMethod.apply(n,arguments):n.queue.push(arguments)};
if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
n.queue=[];t=b.createElement(e);t.async=!0;
t.src=v;s=b.getElementsByTagName(e)[0];
s.parentNode.insertBefore(t,s)}(window, document,'script',
'https://connect.facebook.net/en_US/fbevents.js');
fbq('init', '1298271252097505');
fbq('track', 'PageView');
</script>


<!-- End Meta Pixel Code -->
    <link rel="stylesheet" href="css/all.min_1.css" crossorigin="anonymous" referrerpolicy="no-referrer">
    <style>
        #whatsappbtn {
            position: fixed;
            bottom: 20px;
            right: 0;
            cursor: pointer;
            display: none;
            z-index: 10;
        }

        .whatsapp i {
            background: #25D366;
            color: #ffffff;
            height: 60px;
            width: 60px;
            line-height: 60px;
            display: inline-block;
            text-align: center;
            font-size: 35px;
            border-radius: 50%;
            transition: 0.5s all ease;
            margin-right: 20px;
        }

        .whatsapp i:hover {
            background: #0d1820;
            color: #ffffff;
            box-shadow: 0px 5px 50px rgba(13, 24, 32, 0.05);
        }


        /* call */
        #phonebtn {
            position: fixed;
            bottom: 20px;
            left: 10px;
            cursor: pointer;
            display: none;
            z-index: 10;
        }

        .phone i {
            background: #b28e3b;
            border: 1px solid black;
            color: #ffffff;
            height: 60px;
            width: 60px;
            line-height: 60px;
            display: inline-block;
            text-align: center;
            font-size: 25px;
            border-radius: 50%;
            transition: 0.5s all ease;
            margin-right: 20px;
        }

        .phone i:hover {
            background: #16A34A;
            border: 1px solid #16A34A;
            color: #ffffff;
            box-shadow: 0px 5px 50px rgba(13, 24, 32, 0.05);
        }

        @media (max-width:700px) {
            #whatsappbtn {
                position: fixed;
                bottom: 20px;
                right: 0;
                cursor: pointer;
                display: none;
                z-index: 10;
            }

            .whatsapp i {
                background: #25D366;
                color: #ffffff;
                height: 40px;
                width: 40px;
                line-height: 40px;
                display: inline-block;
                text-align: center;
                font-size: 25px;
                border-radius: 50%;
                transition: 0.5s all ease;
                margin-right: 20px;
            }

            .whatsapp i:hover {
                background: #0d1820;
                color: #ffffff;
                box-shadow: 0px 5px 50px rgba(13, 24, 32, 0.05);
            }

            #phonebtn {
                position: fixed;
                bottom: 20px;
                left: 10px;
                cursor: pointer;
                display: none;
                z-index: 10;
            }

            .phone i {
                background: #16A34A;
                color: #ffffff;
                height: 40px;
                width: 40px;
                line-height: 40px;
                display: inline-block;
                text-align: center;
                font-size: 20px;
                border-radius: 50%;
                transition: 0.5s all ease;
                margin-right: 20px;
            }

            .phone i:hover {
                background: #16A34A;
                color: #ffffff;
                box-shadow: 0px 5px 50px rgba(13, 24, 32, 0.05);
            }
        }
        
        .nav-bar-new{
            background: rgba(0, 0, 0, .75);
            height: 60px;
            padding: 0 50px;
            transition: all .5s ease;
        }
        
        .video1 {
                background: #b28e3b;
        }
    </style>

<!-- Organization Schema -->
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "Organization",
  "name": "Eden Mukteshwar",
  "url": "<?php echo BASE_URL; ?>",
  "logo": "<?php echo BASE_URL; ?>/images/eden_favicon.ico",
  "image": "<?php echo BASE_URL; ?>/images/eden_banner.webp",
  "description": "Eden Mukteshwar offers premium 4 BHK + Servant Room luxury villas in Mukteshwar, Nainital with stunning Himalayan views.",
  "telephone": "+91-9990711766",
  "address": {
    "@type": "PostalAddress",
    "addressLocality": "Mukteshwar",
    "addressRegion": "Uttarakhand",
    "addressCountry": "India"
  },
  "sameAs": [
    "https://www.facebook.com/edenmukteshwar",
    "https://www.instagram.com/edenmukteshwar",
    "https://www.youtube.com/"
  ]
}
</script>

<!-- Residence Schema -->
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "Residence",
  "name": "Eden Mukteshwar",
  "url": "<?php echo BASE_URL; ?>",
  "image": "<?php echo BASE_URL; ?>/images/eden_banner.webp",
  "description": "Eden Mukteshwar offers premium 4 BHK + Servant Room hilltop villas surrounded by nature in Mukteshwar Uttarakhand.",
  "address": {
    "@type": "PostalAddress",
    "addressLocality": "Mukteshwar",
    "addressRegion": "Uttarakhand",
    "addressCountry": "India"
  }
}
</script>

<!-- Real Estate Schema -->
<script type="application/ld+json">
{
 "@context": "https://schema.org",
 "@type": "RealEstateAgent",
 "name": "Eden Mukteshwar Projects",
 "url": "https://edenmukteshwar.com/",
 "areaServed": "Mukteshwar Uttarakhand",
 "makesOffer": [
  {
   "@type": "Offer",
   "name": "Eden Mukteshwar 4 BHK + Servant Room",
   "url": "https://edenmukteshwar.com/"
  }
 ]
}
</script>

<!-- FAQ Schema -->
<script type="application/ld+json">
{
 "@context": "https://schema.org",
 "@type": "FAQPage",
 "mainEntity": [
  {
   "@type": "Question",
   "name": "Where is Eden Mukteshwar located?",
   "acceptedAnswer": {
    "@type": "Answer",
    "text": "Eden Mukteshwar is located in Mukteshwar, Nainital Uttarakhand surrounded by scenic Himalayan views."
   }
  },
  {
   "@type": "Question",
   "name": "What type of property is available in Eden Mukteshwar?",
   "acceptedAnswer": {
    "@type": "Answer",
    "text": "Eden Mukteshwar offers premium 4 BHK + Servant Room luxury villas for investment and vacation homes."
   }
  },
  {
   "@type": "Question",
   "name": "Is Mukteshwar a good place for property investment?",
   "acceptedAnswer": {
    "@type": "Answer",
    "text": "Mukteshwar is one of the fastest growing hill destinations in Uttarakhand, known for scenic beauty and tourism growth."
   }
  },
  {
   "@type": "Question",
   "name": "How can I book a villa in Eden Mukteshwar?",
   "acceptedAnswer": {
    "@type": "Answer",
    "text": "You can contact the Eden Mukteshwar team directly via phone or WhatsApp to schedule a site visit and book your villa."
   }
  }
 ]
}
</script>

<!-- Breadcrumb Schema -->
<script type="application/ld+json">
{
 "@context": "https://schema.org",
 "@type": "BreadcrumbList",
 "itemListElement": [
  {
   "@type": "ListItem",
   "position": 1,
   "name": "Home",
   "item": "https://edenmukteshwar.com/"
  },
  {
   "@type": "ListItem",
   "position": 2,
   "name": "Eden Mukteshwar",
   "item": "https://edenmukteshwar.com/"
  }
 ]
}
</script>
</head>

<body>
    <noscript>
  <img height="1" width="1" style="display:none" src="https://www.facebook.com/tr?id=1298271252097505&ev=PageView&noscript=1" />
</noscript>

    <div id="whatsappbtn" class="whatsapp" style="display: block;">
        <a  href="https://api.whatsapp.com/send?phone=919990711766&text=Hello%2C+I+am+interested+in+the+Eden+Mukteshwar+project+in+Ramgarh.+Please+share+more+details+about+the+location%2C+pricing%2C+amenities%2C+and+availability." target="_blank">
            <i class="fa-brands fa-whatsapp"></i>
        </a>
    </div>
    <div id="phonebtn" class="phone" style="display: block;">
        <a href="tel:+919990711766">
            <i class="fa-solid fa-phone"></i>
        </a>
    </div>



    
    <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-details">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <div class="modal_title">Eden Villas Mukteshwar</div><br/>
                        <div class="modal_subtitle1 text-center mt-1"><i class="fa-solid fa-location-dot"></i>  Ramgarh</div>
                        <div class="modal_subtitle">4 BHK Luxury Villas </div>
                        <hr>
                        <div class="modal_details">Submit Your Query</div>
                        <form  method="POST" action="/contact/email.php">
                            <div class="mb-1">
                                <input type="text" name="name2" class="form-control" placeholder="Enter Name..." required>
                            </div>
                            <div class="mb-1">
                                <input type="email" name="email2" class="form-control" placeholder="Enter Email Address..." required>
                            </div>
                            <div class="mb-1">
                                <input type="number" name="mobile2" class="form-control" pattern="[0-9]{10}" maxlength="10" placeholder="Enter 10-digit number*" required>
                            </div>
                            <div class="mb-1">
                                <input type="text" name="city2" class="form-control" placeholder="Enter Your City..." required>
                            </div>
                            <button type="submit" name="SubmitEnq" class="header_btn1">Submit</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Modal Area End -->

    <!-- Header Start -->
    <header>
        <nav class="navbar navbar-expand-lg bg-body-tertiary nav-bar-new">
            <div class="container-fluid">
                <a class="navbar-brand" href="#">
                    <img src="<?php echo BASE_URL; ?>/images/eden/logo.png" alt="Bootstrap" width="100%" height="55">
                </a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
                        <li class="nav-item">
                            <a class="nav-link" href="#overview">Overview</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#highlights">Highlights</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#amenities">Amenities</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#gallery">Gallery</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#floorplan">Floorplan</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#location">Location</a>
                        </li>

                    </ul>
                    <form class="d-flex" role="search">
                        <li class="navbar-btn">
                            <a href="tel:+919990711766" class="header_btn1"><i class="fa-solid fa-phone"></i> 99907 11766</a>
                        </li>
                    </form>
                </div>
            </div>
        </nav>
    </header>
    <!-- Header End -->

    <main>
        <!-- Slider & Bg Image Start -->
        <section>
            <div class="bg-slider">
                <video class="bg-video" autoplay muted loop playsinline preload="metadata">
                    <source src="<?php echo BASE_URL; ?>/media/eden_vedio.mp4" type="video/mp4">
                    Your browser does not support HTML5 video.
                </video>

                <!-- Bg Content Start -->
                <div class="bg-content pl3">
                    <div class="container-fluid">
                        <div class="row pt2">
                            <div class="col-lg-8 col-md-12">
                                <div class="bg_details">
                                    <div class="d1"><i class="fa-solid fa-location-dot"></i> Ramgarh</div>
                                    <div class="d2">Eden Villas Mukteshwar</div>
                                    <div class="d4">
                                        <p>4 BHK Fully Furnished Luxury Villas </p>
                                    </div>
                                    <div class="card">
                                        <div class="card-body">
                                            <!-- <h5 class="card-title">Key Highlights</h5> -->
                                           <ul class="features-list">
                                                <li>
                                                    <img src="<?php echo BASE_URL; ?>/images/point.png" alt="Eden Mukteshwar">
                                                    Premium Himalayan Villas.
                                                </li>
                                                <li>
                                                    <img src="<?php echo BASE_URL; ?>/images/point.png" alt="Eden Mukteshwar">
                                                    Interior Personalization Support.
                                                </li>
                                                <li>
                                                    <img src="<?php echo BASE_URL; ?>/images/point.png" alt="Eden Mukteshwar">
                                                    Dedicated Relationship Concierge.
                                                </li>
                                                <li>
                                                    <img src="<?php echo BASE_URL; ?>/images/point.png" alt="Eden Mukteshwar">
                                                    24x7 Security & Surveillance.
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                    <div class="d5">Starting Price : <span> ₹ 4.99 Cr* </span> Onwards</div>
                                    <!-- <div class="d5">Starting Price : <span> On Request </span></div> -->
                                    <div class="d-flex" style="align-items: center;">
                                        <a href="#" class="header_btn1" data-bs-toggle="modal" data-bs-target="#exampleModal">Download Brochure</a>
                                        <div class="wrapper">
                                            <div class="video-main">
                                                <div class="promo-video">
                                                    <div class="waves-block">
                                                        <div class="waves wave-1"></div>
                                                        <div class="waves wave-2"></div>
                                                        <div class="waves wave-3"></div>
                                                    </div>
                                                </div>
                                                <a href="#" data-bs-toggle="modal" data-bs-target="#exampleModal" class="video1 video-popup mfp-iframe" data-lity=""><i class="fa fa-play"></i></a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-4 col-md-12">
                                <div class="reg_form">
                                    <form action="/contact/email.php" method="POST">
                                        <h1>We're Here to Help — Get in Touch Today!</h1>
                                        <div class="mb-1">
                                            <input type="text" id="name2" name="name2" class="form-control" placeholder="Enter Name..." required>
                                        </div>
                                        <div class="mb-1">
                                            <input type="email" name="email2" class="form-control" id="email" placeholder="Enter Email Address..." required>
                                        </div>
                                        <div class="mb-1">
                                            <input type="number" name="mobile2" class="form-control" id="number" pattern="[0-9]{10}" maxlength="10" placeholder="Enter 10-digit number*" required>
                                        </div>
                                        <div class="mb-1">
                                <input type="text" name="city2" class="form-control" placeholder="Enter Your City..." required>
                            </div>
                                        <button type="submit" name="SubmitEnq" class="header_btn1">Submit</button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- Bg Content End -->
            </div>
        </section>
        <!-- Slider & Bg Image End -->

        
        <!-- Overview Section Start -->
        <section>
            <div class="overview pt2">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-6 col-md-12 order-lg-1 order-md-1 order-1">
                           <div class="row g-3">
                                <div class="col-6">
                                    <img src="<?php echo BASE_URL; ?>/images/project_images/1754995632_projact ultra wide view.webp"
                                         alt="Eden Mukteshwar ultra wide view project"
                                         class="img1"
                                         loading="lazy">
                            
                                    <img src="<?php echo BASE_URL; ?>/images/project_images/1754995632_projact wide view.webp"
                                         alt="Eden Mukteshwar wide view luxury villas"
                                         class="img2"
                                         loading="lazy">
                                </div>
                            
                                <div class="col-6">
                                    <img src="<?php echo BASE_URL; ?>/images/project_gallery/fp_689b1cfa8a4800.68158538.png"
                                         alt="Eden Mukteshwar floor plan layout"
                                         class="img2"
                                         loading="lazy">
                            
                                    <img src="<?php echo BASE_URL; ?>/images/project_gallery/fp_689b1cfa8b5447.41242341.png"
                                         alt="Eden Mukteshwar master plan design"
                                         class="img1"
                                         loading="lazy">
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-6 col-md-12 order-lg-2 order-md-2 order-2">
                            <div class="overview_content">
                                <div class="title"><img src="<?php echo BASE_URL; ?>/images/check.png" alt="check" class="check" loading="lazy" aria-hidden="true"> Overview</div>
                                <div class="subtitle"> Eden Villas Mukteshwar</div>
                                <div class="details">Welcome to Eden Mukteshwar, a premium collection of low-rise luxury villas in Mukteshwar, Uttarakhand. Nestled at 7,500 ft. in the Kumaon Himalayas, this exclusive township spans 2.75 acres of lush green hilltops, surrounded by fruit orchards, pine forests, and breathtaking Himalayan landscapes.
                                </div>
                                <p>
                                    With 180° unobstructed views of snow-capped peaks like Nanda Devi, Trishul, and Nanda Ghunti, Eden Mukteshwar offers an unmatched lifestyle—ideal for both a serene mountain retreat and a high-value holiday home investment in Uttarakhand.
                                </p>
                                <p>
                                  Residents at Eden Mukteshwar enjoy thoughtfully designed villas and world-class amenities including a modern gymnasium,  indoor games arena, banquet hall, and landscaped gardens—all crafted to elevate health, leisure, and community living.
                                </p>
                                <p>At Eden Mukteshwar, you don’t just buy a villa—you embrace a lifestyle of luxury, wellness, and tranquility in the Himalayas.</p>
                               <div class="mb-4">
                                    <div class="points">
                                        <span>
                                            <img src="<?php echo BASE_URL; ?>/images/check1.png" alt="" class="check" loading="lazy" aria-hidden="true">
                                            Cradled by the Himalayas
                                        </span>
                                
                                        <span>
                                            <img src="<?php echo BASE_URL; ?>/images/check1.png" alt="" class="check" loading="lazy" aria-hidden="true">
                                            Wide open decks designed for stillness and stargazing
                                        </span>
                                    </div>
                                
                                    <div class="points">
                                        <span>
                                            <img src="<?php echo BASE_URL; ?>/images/check1.png" alt="" class="check" loading="lazy" aria-hidden="true">
                                            A private retreat with modern indulgences
                                        </span>
                                
                                        <span>
                                            <img src="<?php echo BASE_URL; ?>/images/check1.png" alt="" class="check" loading="lazy" aria-hidden="true">
                                            Heritage-inspired design, crafted for modern hill living
                                        </span>
                                    </div>
                                </div>
                                <a href="#" class="header_btn1" data-bs-toggle="modal" data-bs-target="#exampleModal">Download Brochure</a>
                            </div>
                        </div>
                    </div>

                </div>
                    <div id="highlights"></div>
            </div>
        </section>
        <!-- Overview Section End -->

        <!-- Highlights Section Start -->
        <section>
            <div class="highlights">
                <div class="container pt2">
                    <div class="h_title">
                        <div class="row">
                            <div class="col-lg-12">
                                <div class="left">
                                    <p> <img src="<?php echo BASE_URL; ?>/images/check.png" alt="" class="check" loading="lazy" aria-hidden="true">Eden Highlights</p>
                                    <h2>A Life Above the Ordinary...</h2>
                                    <span>Where Nature Meets Elegance... Eden Mukteswar is a serene hilltop community in the heart of Mukteswar, blending panoramic Himalayan vistas, peaceful forest surroundings, and contemporary living — a sanctuary crafted for those who seek harmony, comfort, and elevated living.<p></p>
                                </span></div>
                            </div>
                        </div>
                    </div>
                    
           
                    <div class="row">
                        <div class="col-lg-3 col-md-4">
                            <div class="card">
                                <div class="card-body">
                                    <h5 class="card-title">2.75 Acres of Prime Hilltop Land</h5>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-3 col-md-4">
                            <div class="card">
                                <div class="card-body">
                                    <h5 class="card-title">180° Panoramic Himalayan Views</h5>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-3 col-md-4">
                            <div class="card">

                                <div class="card-body">
                                    <h5 class="card-title">Located at 7,500 ft. in the Himalayas</h5>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-3 col-md-4">
                            <div class="card">
                                <div class="card-body">
                                    <h5 class="card-title">Banquet Hall for Community Events</h5>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-3 col-md-4">
                            <div class="card">
                                <div class="card-body">
                                    <h5 class="card-title">Top-Class Specifications & Finishes</h5>
                                </div>
                            </div>
                        </div> 
                        <div class="col-lg-3 col-md-4">
                            <div class="card">
                                <div class="card-body">
                                    <h5 class="card-title">Ultra-Luxury Low-Rise Villas</h5>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-3 col-md-4">
                            <div class="card">

                                <div class="card-body">
                                    <h5 class="card-title">Developed by Winterhill & Propsathi </h5>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-3 col-md-4">
                            <div class="card">

                                <div class="card-body">
                                    <h5 class="card-title">Listed on Airbnb</h5>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- Highlights Section End -->


        <!-- Contect Us Area Start -->
        <section style="margin-top: 40px;">
            <div class="contactus">
                <div class="container">
                    <div class="content">
                        <div class="row">
                            <div class="col-lg-9 col-md-12">
                                <div class="slot">
                                    <h4><img src="<?php echo BASE_URL; ?>/images/line.png" alt="" aria-hidden="true" loading="lazy">  Your Queries Matter. Contact Our Team Now!</h4>
                                    <p>Have questions or need assistance? Our expert team is here to help you every step of the way. Reach out now for personalized support, quick responses, and complete peace of mind.</p>
                                </div>
                            </div>
                            <div class="col-lg-3 col-md-12 text-center">
                                <a href="#" class="header_btn1" data-bs-toggle="modal" data-bs-target="#exampleModal">Book Slot Now</a>
                            </div>
                        </div>
                <div id="amenities"></div>
                    </div>
                </div>
            </div>
        </section>
        <!-- Contect Us Area End -->

        <!-- Amenities Content Start -->
        <section>
            <div class="amenities pt4">
                <div class="container">
                    <div class="amenities_title">
                        <div class="row">
                            <div class="col-lg-12 col-md-12">
                                <div class="title"><img src="images/check.png" alt=""> Amenities</div>
                                <div class="subtitle">Lifestyle Beyond Expectations</div>
                                <p>Where every amenity is thoughtfully designed to reflect elegance, comfort, and
                                    timeless charm. From wellness spaces to leisure zones, discover a life that blends
                                    modern indulgence with classic sophistication.
                            </p></div>
                        </div>
                    </div>

                    <div class="amenities_content">
                        <div class="row">
                            <div class="col-xl-4 col-md-4">
                                <div class="card">
                                    <div class="card-body">
                                        <div class="icon"><img src="images/check.png" alt="" class="am_img"></div>
                                        <h5 class="card-title">Designer Gym</h5>
                                        <p class="card-text">State-of-the-art fitness arena for a healthier you</p>
                                    </div>
                                </div>
                            </div>
                             
                            <div class="col-xl-4 col-md-4">
                                <div class="card">
                                    <div class="card-body">
                                        <div class="icon"><img src="images/check.png" alt="" class="am_img"></div>
                                        <h5 class="card-title">Clubhouse</h5>
                                        <p class="card-text">A lavish social hub with fitness, games & family spaces.
                                        </p>
                                    </div>
                                </div>
                            </div> 
                            <div class="col-xl-4 col-md-4">
                                <div class="card">
                                    <div class="card-body">
                                        <div class="icon"><img src="images/check.png" alt="" class="am_img"></div>
                                        <h5 class="card-title">Helipad</h5>
                                        <p class="card-text">Ensuring rapid aerial transportation through a dedicated helipad zone</p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-4 col-md-4">
                                <div class="card">
                                    <div class="card-body">
                                        <div class="icon"><img src="images/check.png" alt="" class="am_img"></div>
                                        <h5 class="card-title">Spa</h5>
                                        <p class="card-text">A calm retreat for rejuvenation and relaxation.</p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-4 col-md-4">
                                <div class="card">
                                    <div class="card-body">
                                        <div class="icon"><img src="images/check.png" alt="" class="am_img"></div>
                                        <h5 class="card-title">Car Parking</h5>
                                        <p class="card-text">Well-planned, secure parking for residents and guests.</p>
                                    </div>
                                </div>
                            </div> 
                        </div>
                    </div>
                    <div id="gallery"></div>
                </div>
            </div>
        </section>
        <!-- Amenities Content End -->

        <!-- Gallery Section Start -->
       <div class="gallery pt2">
    <div class="container">
        
        <div class="gallery_title">
            <div class="title">
                <img src="<?php echo BASE_URL; ?>/images/check.png" alt="" aria-hidden="true">
                Gallery
            </div>
            <div class="subtitle">
                A gallery of elegance nestled in nature — where grandeur meets green living.
            </div>
        </div>

        <div class="gallery_img">
            <div class="row">

                <div class="col-lg-4 col-md-6">
                    <img src="<?php echo BASE_URL; ?>/images/project_gallery/fp_689b1cfa8a4800.68158538.png"
                         alt="Eden Mukteshwar luxury villa view 1"
                         class="img1"
                         loading="lazy">

                    <img src="<?php echo BASE_URL; ?>/images/project_gallery/fp_689b1cfa8b5447.41242341.png"
                         alt="Eden Mukteshwar villa wide view"
                         class="img2"
                         loading="lazy">
                </div>

                <div class="col-lg-4 col-md-6">
                    <img src="<?php echo BASE_URL; ?>/images/project_gallery/fp_689b1cfa8ce805.67009338.png"
                         alt="Eden Mukteshwar architecture design"
                         class="img3"
                         loading="lazy">

                    <img src="<?php echo BASE_URL; ?>/images/project_gallery/fp_689b1cfa8d4bc6.92397244.png"
                         alt="Eden Mukteshwar interior landscape view"
                         class="img3"
                         loading="lazy">
                </div>

                <div class="col-lg-4 col-md-6">
                    <img src="<?php echo BASE_URL; ?>/images/project_gallery/fp_689b1cfa8e1775.85389646.png"
                         alt="Eden Mukteshwar scenic hill view"
                         class="img2"
                         loading="lazy">

                    <img src="<?php echo BASE_URL; ?>/images/project_images/1754884346_b_s_img2.webp"
                         alt="Eden Mukteshwar premium villa exterior"
                         class="img1"
                         loading="lazy">
                </div>

            </div>
        </div>

    </div>
</div>
        <!-- Gallery Section End -->

        <!-- Video Section Start -->
        <div class="video">
            <!-- Background video -->
            <video class="bg-video" autoplay muted loop playsinline preload="metadata" poster="<?php echo BASE_URL; ?>/images/video-poster.jpg">
                <source src="<?php echo BASE_URL; ?>/media/eden_vedio.mp4" type="video/mp4">
                Your browser does not support HTML5 video.
            </video>

            <!-- Play Button -->
            <div class="play">
                <div class="circle">
                    <a href="#" data-bs-toggle="modal" data-bs-target="#exampleModal">EXPLORE</a>
                </div>
            </div>
        </div>
        <!-- Video Section End -->

        <div id="floorplan"></div>
        <!-- Floorplan Section Start -->
        <div class="floorplan pt2">
            <div class="container">
                <div class="floorplan_title">
                    <div class="title"><img src="<?php echo BASE_URL; ?>/img1/check.png" alt="" loading="lazy" aria-hidden="true"> Project Floorplan</div>
                    <div class="subtitle">Explore well-planned layouts that blend comfort and functionality</div>
                </div>
                <div class="floorplan_content">
                    <div class="row">
                        <div class="col-lg-6 col-md-12">
                            <div class="card card1">
                                <img src="<?php echo BASE_URL; ?>/images/fp2.png" class="card-img-top animate" alt="Eden Mukteshwar floor plan view" loading="lazy">
                                <div class="card-body">
                                    <div class="d-flex justify-content-between">
                                        <h3 class="card-title">Master Plan</h3>
                                        <img src="<?php echo BASE_URL; ?>/images/master-plan.png" alt="Eden Mukteshwar master plan layout" class="mp" loading="lazy">
                                    </div>
                                    <hr>
                                    <a href="#" data-bs-toggle="modal" data-bs-target="#exampleModal">Unlock Now <img src="images/arrow-right.png" alt="" class="arrow2"></a>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-6 col-md-12">
                            <div class="apartment_section">
                                <div class="card mb-3">
                                    <div class="row g-0">
                                         
                                    </div>
                                </div>
                                <div class="card mb-3">
                                    <div class="row g-0">
                                        <div class="col-md-5">
                                            <img src="<?php echo BASE_URL; ?>/images/fp2.png" class="img-fluid rounded-start animate" alt="Eden Mukteshwar floor plan view" loading="lazy">
                                        </div>
                                        <div class="col-md-7">
                                            <div class="card-body">
                                                <div class="d-flex justify-content-between">
                                                    <h4 class="card-title">4 BHK</h4>
                                                    <img src="<?php echo BASE_URL; ?>/images/plan.png" alt="Eden Mukteshwar villa plan layout" class="plan" loading="lazy">
                                                </div>
                                                <hr>
                                                <div class="details">
                                                    <p><b><i class="fa-solid fa-indian-rupee-sign"></i>  Price</b>
                                                    </p>
                                                    :
                                                    <p> <a href="#" data-bs-toggle="modal" data-bs-target="#exampleModal">On Request</a></p>
                                                </div>
                                                <div class="details">
                                                    <p><b><i class="fa-solid fa-expand"></i>  Size</b></p>
                                                    :
                                                    <p> <a href="#" data-bs-toggle="modal" data-bs-target="#exampleModal">On Request</a></p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div> 
                            </div>
                        </div>
                    </div>
                </div>
                <div id="location"></div>
            </div>
        </div>
        <!-- Floorplan Section End -->

        <!-- Location Section Start -->
        <div class="location pt2">
            <div class="container">
                <div class="row">
                    <div class="col-lg-6">
                        <div class="location_title">
                            <div class="title"><img src="<?php echo BASE_URL; ?>/images/check.png" alt="" loading="lazy" aria-hidden="true"> Location Advantages</div>
                            <div class="subtitle">A Landmark Address at Ramgarh</div>
                        </div> 
                        <div class="location_content">
                            <ul>
                                <li><i class="fa-solid fa-location-dot"></i>  Bhalugarh/Bhalu Gaad Waterfall - 8 km</li>
                                <li><i class="fa-solid fa-location-dot"></i>  Nainital  – 15 km</li>
                                <li><i class="fa-solid fa-location-dot"></i>  Kainchi Dham Temple – 12 km</li>
                                <li><i class="fa-solid fa-location-dot"></i>  Bhimtal  - 20 km</li>
                                <li><i class="fa-solid fa-location-dot"></i>  Asia's Biggest Star Gazing - 15 km</li>
                                <li><i class="fa-solid fa-location-dot"></i>  Pantnagar Airport - 55 km</li>
                            </ul>
                        </div>
                        <a href="#" class="header_btn1" data-bs-toggle="modal" data-bs-target="#exampleModal">Explore
                            Now</a>
                    </div>
                    <div class="col-lg-6">
                        <div class="image-hover-effect">
                                <img src="<?php echo BASE_URL; ?>/images/location.jpg" alt="Eden Mukteshwar location map showing project site in Mukteshwar Nainital" class="location_img" loading="lazy">
                                <button data-bs-toggle="modal" data-bs-target="#exampleModal" target="_blank" class="header_btn1 view-map-btn">View Map</button>
                            </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Location Section End -->

        <!-- Contcat Us Section Start -->
        <div class="contact_us">
            <div class="container">
                <h2>Book Site Visit Now</h2>
                <p>Have questions or want to schedule a site visit? We're here to help! Reach out to us and our team
                    will assist you every step of the way.</p>
                <form action="/contact/email.php" method="post">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="mb-4">
                                <input type="text" class="form-control" name="name2" placeholder="Enter Your Name*" required>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="mb-4">
                                <input type="email" class="form-control" name="email2" placeholder="Enter Email Address*" required>
                            </div>
                        </div>
                        <div class="col-md-12">
                            <div class="mb-4">
                                <input type="number" class="form-control" name="mobile2" pattern="[0-9]{10}" maxlength="10" placeholder="Enter 10-digit number*" required>
                            </div>
                        </div>
                         <div class="col-md-12">
                            <div class="mb-4">
                                <input type="text" class="form-control" name="city2" placeholder="Enter Your City*" required>
                            </div>
                        </div>
                    </div>
                    <button type="submit" name="SubmitEnq" class="header_btn1">Submit</button>
                </form>
            </div>
        </div>
        <!-- Contcat Us Section End -->
    </main>


    <footer class="sp6">
        <div class="container">
            <div class="footer-content">
               
                <p>
                    Disclaimer : This website is only for the purpose of providing information About the Eden project. Any information which is being provided on this website is not an advertisement or a solicitation. The company has not verified the information and the compliances of the projects. Further, the company has not checked the RERA* registration status of the real estate projects listed herein. The company does not make any representation in regards to the compliances done against these projects. Please note that you should make yourself aware about the RERA* registration status of the project.
                    <a href="privacy-policy.php">Privacy Policy</a>
                </p>
            </div>
        </div>
    </footer>

    <script src="js/bootstrap.min.js"></script>
    <script>
        document.addEventListener("DOMContentLoaded", function() {
            var myModal = new bootstrap.Modal(document.getElementById('exampleModal'));
            myModal.show();
        });

     
    </script>
    



</body></html><!-- Modal -->