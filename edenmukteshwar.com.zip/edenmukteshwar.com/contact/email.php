<?php 
session_start();  
use PHPMailer\PHPMailer\PHPMailer; 
use PHPMailer\PHPMailer\Exception;  
require 'vendor/autoload.php';    

$name    = htmlentities($_POST['name2'], ENT_QUOTES, 'UTF-8'); 
$email   = htmlentities($_POST['email2'], ENT_QUOTES, 'UTF-8'); 
$phone   = htmlentities($_POST['mobile2'], ENT_QUOTES, 'UTF-8'); 
$city    = htmlentities($_POST['city2'], ENT_QUOTES, 'UTF-8'); 

// Check if the form fields are set and not empty
if(isset($name) && isset($email) && isset($phone) &&
   !empty($name) && !empty($email) && !empty($phone)) {        

    $project     = "Eden Mukteshwar Villas"; 
    $desc        = htmlentities($_POST['message'], ENT_QUOTES, 'UTF-8'); 
    $project_id  = htmlentities($_POST['project_id'], ENT_QUOTES, 'UTF-8');     

    // Store form data in session     
    $_SESSION['postEnquiry']['name'] = $name; 
    $_SESSION['postEnquiry']['email'] = $email; 
 

$descRow = '';
if (!empty($desc)) {
    $descRow = "
    <tr>
        <td style='background: #e74c3c; color: #fff; text-align: center;'>Description</td>
        <td style='text-align: center;'>{$desc}</td>
    </tr>";
}
    // Create HTML email body
    $body = "
    <html>
        <body>
            <h2>Dear Applicant,</h2>
            <h4>Mr./Mrs. {$name}</h4>
            <p>Enquiry For <strong>{$name}</strong></p>
            <p>New Enquiry from Eden Winterhill Landing Site.</p>

            <table border='1' cellpadding='10' cellspacing='0' style='border-collapse: collapse;'>
                <tr style='background: #1b93e1; color: #fff;'>
                    <th colspan='2' style='text-align: center;'>Winterhill Enquiry Details</th>
                </tr>
                <tr>
                    <td style='background: #e74c3c; color: #fff; text-align: center;'>Project Name</td>
                    <td style='text-align: center;'>{$project}</td>
                </tr>
                
                <tr>
                    <td style='background: #e74c3c; color: #fff; text-align: center;'>Name</td>
                    <td style='text-align: center;'>{$name}</td>
                </tr>
                
                <tr>
                    <td style='background: #e74c3c; color: #fff; text-align: center;'>Phone Number</td>
                    <td style='text-align: center;'>{$phone}</td>
                </tr>
                <tr>
                    <td style='background: #e74c3c; color: #fff; text-align: center;'>Email</td>
                    <td style='text-align: center;'>{$email}</td>
                </tr>
                <tr>
                    <td style='background: #e74c3c; color: #fff; text-align: center;'>City</td>
                    <td style='text-align: center;'>{$city}</td>
                </tr>
                $descRow
            </table>

            <p style='margin-top: 30px;'>
                <strong>Thanks</strong><br>
                Eden Mukteshwar
            </p>
        </body>
    </html>";
    
// PHPMailer Setup
$mail = new PHPMailer(true);
$subject = "Eden Mukteshwar  Villas Enquiry";
try {
    // Server settings
    $mail->isSMTP();
    $mail->Host = 'mail.edenmukteshwar.com'; 
    $mail->SMTPAuth = true;
    $mail->Username = 'info@edenmukteshwar.com';  
    $mail->Password = 'CIYyc88&)41FDiZ#';  
    $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
    $mail->Port = 587;

    // Recipients
    
   $to = ['winterhillbysagar@gmail.com'];  
    foreach ($to as $recipient) {
        $mail->addAddress($recipient); // Add each recipient to the email
    }
    $mail->setFrom('info@winterhill.in', 'Eden Mukteshwar  Villas Enquiry');
     
    //$mail->addBCC('xyz@gmail.com'); 
    //$mail->addBCC('abc@gmail.com'); 
    // Email content
    $mail->isHTML(true);
    $mail->Subject = $subject;
    $mail->Body    = $body;
 
    if($mail->send()) {
        echo "<script>window.location.href='thank-you.php'</script>";
    } else {
         echo "<script>window.location.href='/'</script>";
    }
 
} catch (Exception $e) { 
    echo "error".$e;
} 
 
   }


?>
