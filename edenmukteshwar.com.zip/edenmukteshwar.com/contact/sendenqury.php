<?php
session_start() ;
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'vendor/autoload.php'; 

 $name = $_POST['tname'];
 $email = $_POST['temail'];
 $phone = $_POST['tphone']; 
 $desc = $_POST['tmessage']; 
 

 $_SESSION['postEnquiry'] = $_POST ;
// Create HTML email body
$body = "
<html>
    <body>
        <h2>Dear Applicant,</h2>
        <h4>Mr./Mrs. {$name}</h4>
        <p>Enquiry For <strong>{$name}</strong></p>
        <p>Please visit the website regularly for Project Status updates.</p>

        <table border='1' cellpadding='10' cellspacing='0' style='border-collapse: collapse;'>
            <tr style='background: #1b93e1; color: #fff;'>
                <th colspan='2' style='text-align: center;'>Enquiry Details</th>
            </tr>
            <tr>
                <td style='background: #e74c3c; color: #fff; text-align: center;'>Name</td>
                <td style='text-align: center;'>{$name}</td>
            </tr>
            <tr>
                <td style='background: #e74c3c; color: #fff; text-align: center;'>Phone Number</td>
                <td style='text-align: center;'>{$phone}</td>
            </tr>
            <tr>
                <td style='background: #e74c3c; color: #fff; text-align: center;'>Email</td>
                <td style='text-align: center;'>{$email}</td>
            </tr>
            <tr>
                <td style='background: #e74c3c; color: #fff; text-align: center;'>Description</td>
                <td style='text-align: center;'>{$desc}</td>
            </tr>
        </table>

        <p style='margin-top: 30px;'>
            <strong>Thanks,</strong><br>
            Ultra Luxury Floors
        </p>
    </body>
</html>";

// PHPMailer Setup
$mail = new PHPMailer(true);
$subject = "Ultra Luxury Winterhill Plots Enquiry";
try {
    // Server settings
    $mail->isSMTP();
    $mail->Host = 'mail.winterhill.in'; 
    $mail->SMTPAuth = true;
    $mail->Username = 'info@winterhill.in';  
    $mail->Password = 'Winter@0000';  
    $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
    $mail->Port = 587;

    // Recipients
    
   $to = ['winterhillbysagar@gmail.com',  'info@winterhill.in'];
    
    foreach ($to as $recipient) {
        $mail->addAddress($recipient); // Add each recipient to the email
    }
    $mail->setFrom('info@winterhill.in', 'Ultra Luxury Winterhill Plots');
     
    //$mail->addBCC('xyz@gmail.com'); 
    //$mail->addBCC('abc@gmail.com'); 
    // Email content
    $mail->isHTML(true);
    $mail->Subject = $subject;
    $mail->Body    = $body;
 
    if($mail->send()) {
        echo "<script language='javascript'>window.location.href='thank-you.php';</script>";
    } else {
        echo "<script language='javascript'>alert('Sorry! Email could not be sent.'); window.location.href='index.php';</script>";
    }
} catch (Exception $e) { 
    echo "<script language='javascript'>alert('Sorry! Form not submitted. Mailer Error: {$mail->ErrorInfo}'); window.location.href='index.php';</script>";
} 
 


?>
