<?php
session_start() ;
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
define('BASE_URL', 'https://propsathi.in/landing-website-setting');

require 'vendor/autoload.php'; 
$mail = new PHPMailer(true); 
$content = '';
$name =  $_SESSION['postEnquiry']['name'] ;
$email =  $_SESSION['postEnquiry']['email'] ;
 
$body = "" ;
$datetime= date('dmY_hms'); 
   $message = "
            <html> 
             <body>";  
			$body .= '<h4>'.'Dear '.' ' .$name.',</h4>';
			$body .= '<div class="row">';
		  
			$body .="<div style='margin-bottom:15px;margin-top:10px'>Thank you for reaching out to us and showing interest in our projects at Eden Mukteshwar.</div>";
			$body .= "</div>"; 
			
			$body .="<div style='margin-bottom:15px;margin-top:10px'>We have received your inquiry and our team is reviewing it. One of our represntatives will get back to you shortly with the information or assistance you require.</div>";
			 
			
			$body .="<div style='margin-bottom:15px;margin-top:10px'>If you have any urgent questions, feel free to contact us directly at <a href='tel:+91 9990711766'><b style='color:blue'>9990711766</b></a> or email us at <a href='mailto:winterhillbysagar@gmail.com'><u  style='color:blue'>winterhillbysagar@gmail.com</u></a></div>";
			 
			
				$body .="<div style='margin-bottom:15px;margin-top:10px'>
				We appreciate your interest in Eden Mukteshwar and look forward to assisting you.
				</div>";  

$body .= "<div class='col-md-12' style='margin-top:30px;width:100%'>
							<h4>Best regards,</h4>
                            <b>Eden Mukteshwar Team </b><br>
							<b><a href='https://edenmukteshwar.com/'> https://edenmukteshwar.com/</a></b><br>
							<b>9990711766</b><br>
						</div>"; 
			$body .= '</div>';
			$body .= "</table>"; //closes the table
			 
			 
			 
            $message .= $body . "
            </body>
            </html>";
            $message = wordwrap($message, 70);   

          /*  $mail->isSMTP();
            $mail->Host       = 'smtp.gmail.com';
            $mail->SMTPAuth   = true;
            $mail->Username   = 'winterhillbysagar@gmail.com';            
            $mail->Password   = 'kextvhftcvogqcnq';              
            $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;      
            $mail->Port       = 465; */
            
              // Server settings
            $mail->isSMTP();
            $mail->Host = 'mail.edenmukteshwar.com'; 
            $mail->SMTPAuth = true;
            $mail->Username = 'info@edenmukteshwar.com';  
            $mail->Password = 'CIYyc88&)41FDiZ#';  
            $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
            $mail->Port = 587;
            
            $mail->setFrom('winterhillbysagar@gmail.com', 'Eden Mukteshwar Villas');
            $mail->addAddress($email, $name);                    // Recipient
            $mail->isHTML(true);
            $mail->Subject = 'Thank You for Your Inquiry';
            $mail->Body    = $message;
            
             
            
            
            
if(strlen($email) && $email){
    if($mail->send()){
   
?>

<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Thank You </title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <style>
    body {
      margin: 0;
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      background: linear-gradient(to right, #1c1c1c, #0f0f0f);
      color: #ffffff;
      display: flex;
      justify-content: center;
      align-items: center;
      height: 100vh;
      overflow: hidden;
    }

    .thank-you-box {
      text-align: center;
      padding: 50px 30px;
      background: rgba(255, 255, 255, 0.05);
      border: 1px solid rgba(255, 255, 255, 0.1);
      border-radius: 20px;
      box-shadow: 0 10px 25px rgba(0,0,0,0.5);
      max-width: 600px;
      backdrop-filter: blur(15px);
    }

    .thank-you-box h1 {
      font-size: 48px;
      margin-bottom: 10px;
      color: #e6b70a;
    }

    .thank-you-box p {
      font-size: 18px;
      color: #ccc;
      margin-bottom: 30px;
    }

    .thank-you-box .home-btn {
      display: inline-block;
      padding: 12px 30px;
      font-size: 16px;
      border-radius: 50px;
      background-color: #e6b70a;
      color: #000;
      text-decoration: none;
      font-weight: bold;
      transition: background-color 0.3s ease;
    }

    .thank-you-box .home-btn:hover {
      background-color: #cfa209;
    }

    .logo {
      margin-bottom: 30px;
    }

    .logo img {
      width: 120px;
    }

    @media (max-width: 600px) {
      .thank-you-box h1 {
        font-size: 36px;
      }
      .thank-you-box p {
        font-size: 16px;
      }
    }
  </style>
</head>
<body>

  <div class="thank-you-box">
    <div class="logo">
      <img src="<?php echo BASE_URL; ?>/images/eden/logo.png" alt="Eden Mukteshwar"> <!-- Replace with actual logo path -->
    </div>
    <h1>Thank You!</h1>
    <p>Your enquiry has been successfully submitted.<br>Our team will connect with you shortly.</p>
    <a href="/" class="home-btn">Return to Home</a>
  </div>
 <script>
  setTimeout(function() {
    window.location.href = '/'; // Change to 'index.php' if needed
  }, 5000); // 5000 ms = 5 seconds
</script>
<?php

}else{
    echo "Tracking...";
    ?>
  <script>
  setTimeout(function() {
    window.location.href = '/'; // Change to 'index.php' if needed
  }, 5000); // 5000 ms = 5 seconds
</script>
    <?php
}
}
else {
      ?>
   <script>
  setTimeout(function() {
    window.location.href = '/'; // Change to 'index.php' if needed
  }, 5000); // 5000 ms = 5 seconds
</script>
    <?php

    
}
