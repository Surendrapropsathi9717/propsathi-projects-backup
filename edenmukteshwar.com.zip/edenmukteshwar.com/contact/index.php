<!DOCTYPE html>
<html lang="en">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>Contact Us</title>
 
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1" crossorigin="anonymous">
  
<link href="/assets/main.css" rel="stylesheet">  

<link rel="preload" href="/assets/fonts/cinzel-v10-latin-600.woff2" as="font" crossorigin="anonymous">
<link rel="preload" href="/assets/fonts/inter-v2-latin-100.woff2" as="font" crossorigin="anonymous">
<link rel="preload" href="/assets/fonts/inter-v2-latin-regular.woff2" as="font" crossorigin="anonymous">
<link rel="preload" href="/assets/fonts/inter-v2-latin-700.woff2" as="font" crossorigin="anonymous">
<link rel="preload" href="/assets/fonts/icomoon3399.ttf?gxdhmw" as="font" crossorigin="anonymous"> 
<link rel="canonical" href="index.html"> 
<script src="https://cdnjs.cloudflare.com/ajax/libs/lazysizes/5.3.2/lazysizes.min.js" async></script>
 <link href="/assets/main.css" rel="stylesheet">

 
<link rel="preload" href="assets/images/whl_bn1.webp" as="image"> 
<link rel="preload" href="assets/images/whl_bn2.webp" as="image"> 
<link rel="preload" href="assets/images/whl_bn3.webp" as="image">
<style>
    .smart-footer-menu ul { 
    text-align: justify;
    }
</style>
<script src="assets/js/jquery-3.7.1.min.js"></script>
 <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/js/bootstrap.bundle.min.js"></script>
</head>
<body class=""> 
<header id="header">
    <div class="mainhead clear">
        <div class="logo left"><a href="index.html" title="Winterhill Logo">
            <img    data-src="https://lead.propsathi.in/assets/images/logo-white.png" class="lazyload" alt="Winter hill logo"></a></div>
        <div class="right clear">
        	<div class="contact left pointer" onclick="window.location.href = 'tel:+91 70 111 750 64';"><i class="icon-call"></i> <span>70 111 750 64</span></div>
            <div class="contact left pointer"><a href="https://wa.me/+919990711766" class="green" target="_blank"><i class="icon-whatsapp"></i></a></div>
            <div class="menu relative left menubar"><i class="icon-menu"></i></div>
        </div>
    </div>
    <div class="menu-overlay"></div>
    <div class="menu-wrp">
    	<div class="menuclose"><i class="icon-close"></i></div>
            <a href="index.html"><img class="tpr-logo lazyload" data-src="https://lead.propsathi.in/assets/images/logo-white.png" alt="Winterhill Logos"></a>
            <ul>
    <li itemprop="name"><a itemprop="url" class="line-anim" href="/">Home</a></li>
    
    <li itemprop="name" class="visuallyhidden"><a itemprop="url" class="line-anim" target="_blank" href="#">About Us</a></li> 
    <li itemprop="name"><a itemprop="url" class="line-anim" target="_blank" href="/aarambh">The Aarambh Resorts</a></li>
    <li itemprop="name"><a itemprop="url" class="line-anim" target="_blank" href="/winterhill">Winter Hill</a></li>
    <li itemprop="name"><a itemprop="url" class="line-anim" target="_blank" href="/eden">Eden</a></li>
    <li itemprop="name"><a itemprop="url" class="line-anim" href="contact" target="_blank">Contact Us</a></li>
</ul>            <div class="bottom-wrp">
                <a class="gray" href="javascript:;" onclick="window.location.href = 'tel:+91 9990711766';"><i class="icon-headphone"></i> <strong>9990711766</strong></a>
            </div>
    </div>
</header>
<section id="project-gallery">
    <div class="dswitch   gallery slider">
        <a target="_blank" href="#">
            <img fetchpriority="high" data-src="/assets/images/whl_bn3.webp" alt="" class="lazyload">
        </a>
        <a target="_blank" href="#">
            <img fetchpriority="high" data-src="/assets/images/whl_bn2.webp" alt=" " class="lazyload">
        </a>
        
        <a target="_blank" href="#">
            <img fetchpriority="high" data-src="/assets/images/whl_bn1.webp" alt=" " class="lazyload">
        </a>
             
    </div>
    <div class="index-img mswitch">
        <div class="relative shade gallery slider">
            <a target="_blank" href="/aarambh">
                <img fetchpriority="high" data-src="/assets/images/whl_bn1.webp" alt="The Aarambh Resorts Satbunga" class="lazyload">
             
            </a> 
            
            <a target="_blank" href="/eden">
                <img fetchpriority="high" data-src="/assets/images/whl_bn2.webp" alt="Eden Ramgarh" class="lazyload">
            
            </a>
            
             <a target="_blank" href="/eden">
                <img fetchpriority="high" data-src="/assets/images/whl_bn3.webp" alt="Eden Ramgarh" class="lazyload">
            
            </a>
            
        </div>
    </div>
</section>
 
<section id="contacts" class="queform lazy">
    <div class="container-box queshade">
        <div class="calign"><h3 class="title-border-center text-uppercase white">Tell Us What You Need</h3></div>
        <form name="callback" id="signup" method="post" action="email.php">
            <div class="clear">
                <div class="form-floating">
                    <input name="project" value="Winter Hill" type="hidden">
                    <input type="text" name="name" class="form-control" placeholder="Name" required="">
                    <label for="name">Your Name</label>
                </div>
                <div class="form-floating">
                    <input type="tel" name="mobile" class="form-control" placeholder="Mobile" required="">
                    <label for="mobile">Mobile No.</label>
                </div>
                <div class="form-floating">
                    <input type="email" name="email" class="form-control" placeholder="Email" required="">
                    <label for="email">Email ID.</label>
                </div>
                <div class="form-floating"> 
                    <textarea name="message" class="form-control" style="width:100%;  "></textarea>
                    <label for="city">Message</label>
                </div>
            </div>
            <div class="d-block calign">
                <p class="white">Your information will be kept strictly confidential and will not be shared, sold, or otherwise disclosed.</p><br>
                <input type="submit" value=" Submit " name="send" class="btn btn-danger rounded-pill">
            </div>
        </form>
    </div>
</section>
<section id="connect-now" class="container-box">
     <div class="row nopad nomar">
         <div class="col-sm-12 calign nopad nomar">
             <h4 class="h3"><small>Don't be shy  - drop us a line.<br>
             We'are looking forward to speaking to you!</small></h4>
         </div>
         <div class="col-sm-12 calign nopad nomar">
             <a href="https://wa.me/+919990711766" target="_blank" class="green"><i class="icon-whatsapp"></i></a>
             <a href="#" onclick="window.location.href = 'tel:+91 70 111 750 64';" class="blue"><i class="icon-call"></i></a>
         </div>
     </div>
</section>

<section class="container-box3 bg-dark"><p class="gray">Disclaimer : The content provided on this website is for information purposes only and does not constitute an offer to avail any service. The prices mentioned are subject to change without prior notice, and the availability of properties mentioned is not guaranteed. The images displayed on the website are for representation purposes only and may not reflect the actual properties accurately..</p></section>

 
<footer class="smart-footer bg-gray calign">
   <br><br><br>
    <div class="smart-footer-logo" bis_skin_checked="1">
        <a href="index.html" class="smart-footer-logo-link">
            <img data-src="https://lead.propsathi.in/assets/images/logo-2.png" class="smart-footer-logo-img black lazyloaded" alt="Winterhill Logo" src="https://lead.propsathi.in/assets/images/logo-2.png">
        </a>
    </div>
    <div class="row nopad nomar" bis_skin_checked="1">
        <div class="col-sm-5 nopad nomar smart-footer-menu" bis_skin_checked="1">
          <p class="justify">Welcome to Winter Hill LLP. Our single platform designed to meet the needs of buyers, and sellers of properties. If you are intrested in purchasing a home, Villas, studio you can search Winter Hill LLP using our portal to find the right residental property to fit your needs.</p>
        </div>
        
       
        <div class="col-sm-4 nopad nomar smart-footer-menu" bis_skin_checked="1">
           <ul>
               
                <li itemprop="name"><strong>Phone :  </strong><a itemprop="url" class="line-anim" href="tel:9990711766">9990711766</a></li>
                <li itemprop="name"><strong>Email-id : </strong>  <a itemprop="url" class="line-anim" href="mailto:info@winterhill.in">info@winterhill.in</a></li>
                 <li itemprop="name"><strong>Whatsaap : </strong><a itemprop="url" class="line-anim" href="https://api.whatsapp.com/send?phone=+919990711766  &amp;text=Hello, Looking for Winter Hills Mukteshwar. Get in touch with me my name is">9990711766</a></li>
            </ul>
        </div>  
	 
        <div class="col-sm-3 nopad nomar smart-footer-menu" bis_skin_checked="1">
           <ul>
               <li itemprop="name"><a itemprop="url" class="line-anim" href="/aarambh">The Aarambh Resorts</a></li>
                <li itemprop="name"><a itemprop="url" class="line-anim" href="/winterhill">Winterhill</a></li>
                
                 <li itemprop="name"><a itemprop="url" class="line-anim" href="/eden">Eden</a></li>
            </ul>
        </div>
    </div> 

</footer>
	<script src="https://code.jquery.com/jquery-3.3.1.min.js" integrity="sha256-FgpCb/KJQlLNfOu91ta32o/NMZxltwRo8QtmkMRdAu8=" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/js/bootstrap.bundle.min.js" integrity="sha384-ygbV9kiqUc6oa4msXn9868pTtWMgiQaeYH7/t7LECLbyPA2x65Kgf80OJFdroafW" crossorigin="anonymous"></script>
	<script src="/assets/js/slider.js"></script>
	<script src="/assets/js/all.js"></script>
 
<script>
$("#signup").submit(function(e) {
e.preventDefault();
var form = $(this);
var url = form.attr('action');
$.ajax({
     type: "POST",
     url: url,
     data: form.serialize(),
     success: function(data)
     {
    document.getElementById("signup").reset();
       alert(data);
     }
   });
});
</script>
</body>
</html>